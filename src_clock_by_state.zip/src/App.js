import React from 'react';
import Clock from './components/clock'

export default function App() {
  return (
    <Clock />
  )
}